$(document).ready(function() {
    $('.toggle-button').click(function() {
      var target = $(this).data('target');
      $(target).toggleClass('active');
      $(this).toggleClass('active');
      $('.toggle-button').not(this).removeClass('active');
      $('.toggle-section').not(target).removeClass('active');
    });
  });